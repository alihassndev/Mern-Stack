function Footer() {
  return (
    <>
      <div className="w-[80vw] mx-auto border-t border-[#ffffff76] p-8">
        <p className="text-xs text-center">
          &copy; Copyright. All Rights Reserved
        </p>
      </div>
    </>
  );
}

export default Footer;
