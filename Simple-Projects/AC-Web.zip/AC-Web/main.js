// === Modal Script ===
const openModalBtns = document.querySelectorAll("[data-open-modal]");
const closeModalBtn = document.getElementById("closeModal");
const modal = document.getElementById("quoteModal");
const overlay = document.getElementById("overlay");

openModalBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    modal.classList.add("active");
    overlay.classList.add("active");
  });
});

closeModalBtn.addEventListener("click", () => {
  modal.classList.remove("active");
  overlay.classList.remove("active");
});

overlay.addEventListener("click", () => {
  modal.classList.remove("active");
  overlay.classList.remove("active");
});

// === Form Submission using mailto ===
document.getElementById("quoteForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const phone = document.getElementById("phone").value;
  const service = document.getElementById("service").value;
  const message = document.getElementById("message").value;

  const mailtoLink = `mailto:yourtechnicianemail@gmail.com?subject=Service Request from ${name}&body=
Name: ${name}%0D%0AEmail: ${email}%0D%0APhone: ${phone}%0D%0AService: ${service}%0D%0AMessage: ${message}`;

  window.location.href = mailtoLink;
});
